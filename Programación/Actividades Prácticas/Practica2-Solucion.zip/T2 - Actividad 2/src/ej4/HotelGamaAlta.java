package ej4;

public class HotelGamaAlta extends Hotel {
	
	public static final String SUITES = "suites";
	public static final String DOBLES = "dobles";
	public static final String SIMPLES = "simples";
		
	private int suites;
	private int reservaSuites;
	private int dobles;
	private int reservasDobles;
	private int simples;
	private int reservasSimples;

	public HotelGamaAlta(String nombre, int numeroPlantas, int suites, int dobles, int simples) {
		super(nombre, (suites+dobles+simples), numeroPlantas);
		this.suites = suites;
		this.dobles = dobles;
		this.simples = simples;
		this.reservaSuites = 0;
		this.reservasDobles = 0;
		this.reservasSimples = 0;
	}

	@Override
	public void reservar() {
		reservar(SIMPLES);		
	}
	
	public void reservar(String tipo) {
		
		if(tipo.equalsIgnoreCase(SUITES)) {
			if(reservaSuites<suites)	 {
				reservaSuites++;
				System.out.println("Suite reservada");
			} else {
				System.out.println("No es posible hacer la reserva. Suites completas");
			}
							
		} else if (tipo.equalsIgnoreCase(DOBLES)) {
			if(reservasDobles<dobles)	 {
				reservasDobles++;
				System.out.println("Habitaci�n doble reservada");
			} else {
				System.out.println("No es posible hacer la reserva. Habitaciones dobles completas");
			}
		} else if (tipo.equalsIgnoreCase(SIMPLES)) {
			if(reservasSimples>simples) {
				reservasSimples++;
				System.out.println("Habitaci�n simple reservada");
			} else {
				System.out.println("No es posible hacer la reserva. Habitaciones simples completas");
			}
		}
				
	}

	@Override
	public void cancelarReserva() {
		cancelarReserva(SIMPLES);
	}
		
	public void cancelarReserva(String tipo) {
		
		if(tipo.equalsIgnoreCase(SUITES)) {
			if(reservaSuites>0)	{
				reservaSuites--;
				System.out.println("Reserva cancelada en el hotel: " + getNombre());
			} else 
				System.out.println("No se puede cancelar la reserva. No habia ninguna reserva");
		} else if (tipo.equalsIgnoreCase(DOBLES)) {
			if(reservasDobles>0) {			
				reservasDobles--;
				System.out.println("Reserva cancelada en el hotel: " + getNombre());
			} else
				System.out.println("No se puede cancelar la reserva. No habia ninguna reserva");
		} else if (tipo.equalsIgnoreCase(SIMPLES)) {
			if(reservasSimples>0) {
				reservasSimples--;
				System.out.println("Reserva cancelada en el hotel: " + getNombre());
			} else
				System.out.println("No se puede cancelar la reserva. No habia ninguna reserva");
		}		
		
	}
	
}
