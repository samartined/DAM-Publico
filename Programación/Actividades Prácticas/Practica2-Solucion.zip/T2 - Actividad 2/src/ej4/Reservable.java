package ej4;

interface Reservable {
	
	void reservar();

	void cancelarReserva();
	
}
