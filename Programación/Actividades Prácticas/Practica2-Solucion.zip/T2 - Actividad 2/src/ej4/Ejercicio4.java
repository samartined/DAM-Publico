package ej4;

public class Ejercicio4 {

	public static void main(String[] args) {

		Reservable vuelo1 = new Vuelo(101, 1, 1);
		Reservable vuelo2 = new Vuelo(102, 70, 15);
		Reservable hotel1 = new HotelGamaAlta("Hotel rich", 4, 2, 5, 10);
		Reservable hotel2 = new HotelGamaMedia("Hotel B&B", 10, 2);
		HotelGamaMedia hotelGM = new HotelGamaMedia("Hotel medio", 5, 1);
		Reservable hotel3 = new HotelGamaBaja("Hotel cas", 1, 1);

		vuelo1.reservar();
		vuelo1.reservar();
		((Vuelo) vuelo1).reservar(true);
		vuelo1.cancelarReserva();
		vuelo1.reservar();

		vuelo2.reservar();
		vuelo2.reservar();
		vuelo2.cancelarReserva();
		vuelo2.cancelarReserva();
		vuelo2.cancelarReserva();

		hotel1.reservar();
		hotel1.reservar();
		((HotelGamaAlta) hotel1).reservar(HotelGamaAlta.DOBLES);

		((HotelGamaMedia) hotel2).reservar(true);
		hotelGM.reservar(true);
		System.out.println(
				"Total de clientes con catering en todos los hoteles de gama media: " + HotelGamaMedia.getCatering());

		hotel2.cancelarReserva();
		
		for (int i = 1; i <= 10; i++) {
			hotel3.reservar();
		}

		hotel3.reservar();

	}
	
	public static void Test1() {
		
		Reservable vuelo1 = new Vuelo(101, 1, 1);
		Reservable vuelo2 = new Vuelo(102, 70, 15);
		Reservable hotel1 = new HotelGamaAlta("Hotel rich", 4, 2, 5, 10);
		Reservable hotel2 = new HotelGamaMedia("Hotel B&B", 10, 2);
		HotelGamaMedia hotelGM = new HotelGamaMedia("Hotel medio", 5, 1);
		Reservable hotel3 = new HotelGamaBaja("Hotel cas", 1, 1);

		vuelo1.reservar();
		vuelo1.reservar();
		((Vuelo) vuelo1).reservar(true);
		vuelo1.cancelarReserva();
		vuelo1.reservar();

		vuelo2.reservar();
		vuelo2.reservar();

		hotel1.reservar();
		hotel1.reservar();
		((HotelGamaAlta) hotel1).reservar(HotelGamaAlta.DOBLES);

		((HotelGamaMedia) hotel2).reservar(true);
		hotelGM.reservar(true);
		System.out.println(
				"Total de clientes con catering en todos los hoteles de gama media: " + HotelGamaMedia.getCatering());

		hotel2.cancelarReserva();

		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();
		hotel3.reservar();

		hotel3.reservar();

	}

}
