package ej4;

public class HotelGamaBaja extends Hotel {

	private int reservaCamas;

	public HotelGamaBaja(String nombre, int totalHabitaciones, int numeroPlantas) {
		super(nombre, totalHabitaciones, numeroPlantas);
		reservaCamas = 0;
	}

	@Override
	public void reservar() {
		if ((reservaCamas / 10) < getTotalHabitaciones()) {
			reservaCamas++;
			System.out.println(
					"Reserva realizada en el hotel: " + getNombre() + " en la habitacion " + getNumeroHabitacion());
		} else {
			System.out.println("No quedan habitaciones con camas libres");
		}

	}

	public int getNumeroHabitacion() {
		if (reservaCamas % 10 == 0)
			return reservaCamas / 10;

		return (reservaCamas / 10) + 1;
	}

	@Override
	public void cancelarReserva() {
		if(reservaCamas>0) {
			reservaCamas--;
			System.out.println("Reserva cancelada en el hotel: " + getNombre());
		} else {
			System.out.println("No se puede cancelar la reserva. No habia ninguna reserva");
		}
		
	}

}
