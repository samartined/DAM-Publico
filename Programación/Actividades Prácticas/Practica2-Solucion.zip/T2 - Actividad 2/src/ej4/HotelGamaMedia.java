package ej4;

public class HotelGamaMedia extends Hotel {
	
	private static int catering;
	private int reservaHabitaciones;

	public HotelGamaMedia(String nombre, int totalHabitaciones, int numeroPlantas) {
		super(nombre, totalHabitaciones, numeroPlantas);
		setCatering(0);
		reservaHabitaciones = 0;
	}
	
	public static int getCatering() {
		return catering;
	}

	public static void setCatering(int catering) {
		HotelGamaMedia.catering = catering;
	}
	
	@Override
	public void reservar() {
		reservar(false);
	}
	
	public void reservar(boolean catering) {
		if(reservaHabitaciones < getTotalHabitaciones()) {
			if(catering)
				HotelGamaMedia.setCatering(HotelGamaMedia.getCatering() + 1);
			
			reservaHabitaciones++;						
			System.out.println("Reserva realizada en el hotel: " + getNombre());
		}
	}

	@Override
	public void cancelarReserva() {
		cancelarReserva(false);		
	}
	
	public void cancelarReserva(boolean catering) {
		
		if(reservaHabitaciones > 0) {
			reservaHabitaciones--;
			if(catering)
				HotelGamaMedia.setCatering(HotelGamaMedia.getCatering() - 1);
			
			System.out.println("Reserva cancelada en el hotel: " + getNombre());
		} else {
			System.out.println("No se puede cancelar la reserva. No habia ninguna reserva");
		}
		
		
	}	

}
