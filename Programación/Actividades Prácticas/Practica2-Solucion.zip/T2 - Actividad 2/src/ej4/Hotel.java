package ej4;

public abstract class Hotel implements Reservable {
	
	private String nombre;
	private int totalHabitaciones;
	private int numeroPlantas;

	public Hotel(String nombre, int totalHabitaciones, int numeroPlantas) {
		this.nombre = nombre;
		this.totalHabitaciones = totalHabitaciones;
		this.numeroPlantas = numeroPlantas;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getTotalHabitaciones() {
		return totalHabitaciones;
	}

	public void setTotalHabitaciones(int totalHabitaciones) {
		this.totalHabitaciones = totalHabitaciones;
	}

	public int getNumeroPlantas() {
		return numeroPlantas;
	}

	public void setNumeroPlantas(int numeroPlantas) {
		this.numeroPlantas = numeroPlantas;
	}

}