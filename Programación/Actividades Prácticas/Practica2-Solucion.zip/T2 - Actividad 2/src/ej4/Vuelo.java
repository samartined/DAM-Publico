package ej4;

public class Vuelo implements Reservable {

	private int numeroVuelo;
	private int plazasTotales;
	private int plazasVIP;
	private int reservasNormales;
	private int reservasVIP;
	private boolean completo;

	public Vuelo(int numeroVuelo, int plazasNormales, int plazasVIP) {
		this.numeroVuelo = numeroVuelo;
		this.plazasTotales = plazasNormales + plazasVIP;
		this.plazasVIP = plazasVIP;
		this.reservasNormales = 0;
		this.reservasVIP = 0;
		this.completo = false;
	}
	
	public int plazasNormalesLibres() {
		return plazasTotales - plazasVIP - reservasNormales;
	}

	public int plazasVIPLibres() {
		return plazasVIP - reservasVIP;
	}

	public boolean isCompleto() {
		return completo;
	}
	
	public void comprobarSiCompleto() {
		if(reservasNormales + reservasVIP == plazasTotales) {
			completo = true;
		}
	}
	
	@Override
	public void reservar() {
		reservar(false);
	}

	public void reservar(boolean vip) {

		if (!isCompleto()) {
			if (!vip) {
				if (plazasNormalesLibres() > 0) {
					reservasNormales++;
					System.out.println("Reserva realizada en el vuelo " + numeroVuelo + " quedan: " + plazasNormalesLibres() + " plazas libres");
				} else {
					System.out.println("No quedan plazas normales");
				}

			} else {
				if (reservasVIP < plazasVIP) {
					reservasVIP++;
					System.out.println("Reserva VIP realizada en el vuelo " + numeroVuelo + " quedan: " + plazasVIPLibres() + " plazas VIP libres");
				} else {
					System.out.println("No quedan plazas VIPS");
				}
			}
			
			comprobarSiCompleto();
			
		} else {
			System.out.println("El vuelo " + numeroVuelo + " est� completo.");
		}

	}

	@Override
	public void cancelarReserva() {
		cancelarReserva(false);
	}

	public void cancelarReserva(boolean vip) {
		if (!isCompleto()) {
						
			if(!vip) {
				if(reservasNormales>0)
					reservasNormales--;
				else
					System.out.println("No se puede cancelar la reserva. No habia reservas hechas");
			} else { 
				if(reservasVIP>0)
					reservasVIP--;
				else
					System.out.println("No se puede cancelar la reserva. No habia reservas VIP hechas");
			}
			System.out.println("Reserva cancelada en el vuelo " + numeroVuelo);
		} else {
			System.out.println("El vuelo esta completo, se cancela la reserva sin afecto en el vuelo " + numeroVuelo);
		}

	}
}
