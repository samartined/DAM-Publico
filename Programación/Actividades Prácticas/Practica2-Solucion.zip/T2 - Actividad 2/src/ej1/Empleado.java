package ej1;

public class Empleado extends Persona {

	private double sueldo;
	private String categoria;
	private Contrato contrato;

	public Empleado(String dni, String nombre, int edad, double sueldo, String categoria, Empresa empresa, TipoContrato tipoContrato) {
		super(dni, nombre, edad);
		this.sueldo = sueldo;
		this.categoria = categoria;
		this.contrato = new Contrato(this, empresa, tipoContrato);
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Contrato getContrato() {
		return contrato;
	}

	public void setContrato(Contrato contrato) {
		this.contrato = contrato;
	}

	@Override
	public String toString() {
		return "Empleado [sueldo=" + sueldo + ", categoria=" + categoria + ", contrato=" + contrato.toString(false) + "]";
	}

}