package ej1;

public enum TipoContrato {
	   TEMPORAL, INDEFINIDO
}
