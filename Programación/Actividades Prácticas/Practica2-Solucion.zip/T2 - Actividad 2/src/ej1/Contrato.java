package ej1;

import java.util.Date;

public class Contrato {

	private Date fecha;
	private TipoContrato tipo;
	private Empleado empleado;
	private Empresa empresa;

	public Contrato(Empleado empleado, Empresa empresa, TipoContrato tipoContrato) {
		this.empleado = empleado;
		this.empresa = empresa;
		this.fecha = new Date();
		this.tipo = tipoContrato;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public TipoContrato getTipo() {
		return tipo;
	}

	public void setTipo(TipoContrato tipo) {
		this.tipo = tipo;
	}

	public Empleado getEmpleado() {
		return empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public String toString(Boolean completo) {

		if (completo) {
			return "Contrato [fecha=" + fecha + ", tipo=" + tipo + ", empleado=" + empleado + ", empresa=" + empresa
					+ "]";
		}

		return "Contrato [fecha=" + fecha + ", tipo=" + tipo + ", empresa=" + empresa + "]";

	}

}
