package ej1;

public class Ejercicio1 {

	public static void main(String[] args) {

		Empresa empresa = new Empresa("Empresa", "V21035126");
		
		Empleado empleado1 = new Empleado("01", "Antonio", 26, 1200, "Programador junior", empresa, TipoContrato.INDEFINIDO);
		Empleado empleado2 = new Empleado("02", "Carlos", 22, 1600, "Programador senior", empresa, TipoContrato.TEMPORAL);
		Empleado empleado3 = new Empleado("03", "Maria", 40, 2000, "Analista", empresa, TipoContrato.INDEFINIDO);

		System.out.println(empresa.toString());
		System.out.println(empleado1.toString());
		System.out.println(empleado2.toString());
		System.out.println(empleado3.toString());
		
	}

}
