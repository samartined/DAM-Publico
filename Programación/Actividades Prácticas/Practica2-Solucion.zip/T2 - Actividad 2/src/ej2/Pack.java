package ej2;

public class Pack extends Producto {
	
    private float descuento;
    private Producto producto1;
    private Producto producto2;

    public Pack(String id, String nombre, Producto producto1, Producto producto2, float descuento) {
        super(id, nombre);
        
        double precio = 0.0d;
    	
    	if(producto1 != null) 
    		precio = producto1.calcularPrecioFinal();
  
    	if(producto2 != null) 
    		precio += producto2.calcularPrecioFinal(); 
    	     
        super.setPrecio(precio);       
        
        this.producto1 = producto1;
        this.producto2 = producto2;
        this.descuento = descuento;
    }
     
    public float getDescuento() {
		return descuento;
	}

	public void setDescuento(float descuento) {
		this.descuento = descuento;
	}

	@Override
    public double calcularPrecioFinal() { 	
    	return precio * ( 1 - (descuento/100) );  
    }
	
}
