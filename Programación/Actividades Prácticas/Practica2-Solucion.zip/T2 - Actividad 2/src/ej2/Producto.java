package ej2;

public abstract class Producto {
    protected String id;
    protected String nombre;
    protected double precio;
    
    public Producto(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Producto(String id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
    }
 
	public void setPrecio(double precio) {
		this.precio = precio;
	}

    public abstract double calcularPrecioFinal();
}