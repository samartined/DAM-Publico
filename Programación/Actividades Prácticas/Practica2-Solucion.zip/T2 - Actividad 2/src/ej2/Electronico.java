package ej2;

public class Electronico extends Producto {
	
    private static final double TARIFA_RECICLAJE = 10.0;

    public Electronico(String id, String nombre, double precio) {
        super(id, nombre, precio);
    }

    @Override
    public double calcularPrecioFinal() {
        return precio + TARIFA_RECICLAJE;
    }
    
}
