package ej2;

public class Belleza extends Producto {
	
    private static final double IMPUESTO_VENTAS = 0.15;

    public Belleza(String id, String nombre, double precio) {
        super(id, nombre, precio);
    }

    @Override
    public double calcularPrecioFinal() {
        return precio + (precio * IMPUESTO_VENTAS);
    }
    
}
