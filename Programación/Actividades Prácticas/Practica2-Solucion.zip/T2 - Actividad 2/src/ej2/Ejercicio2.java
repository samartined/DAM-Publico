package ej2;

public class Ejercicio2 {

    public static void main(String[] args) {
    	
        Producto p1 = new Electronico("1", "M�vil", 200);
        Producto p2 = new Belleza("2", "Colonia", 10);
        Producto p3 = new Pack("3", "Movil + Colonia", p1, p2, 10);

        System.out.println("Precio final del producto " + p1.nombre + ": " + p1.calcularPrecioFinal());
        System.out.println("Precio final del producto " + p2.nombre + ": " + p2.calcularPrecioFinal());
        System.out.println("Precio final del producto " + p3.nombre + ": " + p3.calcularPrecioFinal());
        
    }

}
