package ej3;

public interface Figura {
	
	/**
	 * Funci�n para calcular un area de una figura
	 * @return
	 */
	public double calcularArea();

	/**
	 * Funci�n para calcular un perimetro de una figura
	 * @return
	 */
	public double calcularPerimetro();
	
}
