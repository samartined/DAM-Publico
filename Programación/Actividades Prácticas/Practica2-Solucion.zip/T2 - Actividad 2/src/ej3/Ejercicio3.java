package ej3;

public class Ejercicio3 {
	
	public static void main(String[] args) {
		Figura circulo = new Circulo(5);
		Figura rectangulo = new Rectangulo(4, 5);
		Figura triangulo = new Triangulo(3, 4, 5, 6);
		Figura rombo = new Rombo(5, 6, 2);

		System.out.println("�rea del c�rculo: " + circulo.calcularArea());
		System.out.println("Per�metro del c�rculo: " + circulo.calcularPerimetro());

		System.out.println("�rea del rect�ngulo: " + rectangulo.calcularArea());
		System.out.println("Per�metro del rect�ngulo: " + rectangulo.calcularPerimetro());

		System.out.println("�rea del tri�ngulo: " + triangulo.calcularArea());
		System.out.println("Per�metro del tri�ngulo: " + triangulo.calcularPerimetro());
		
		System.out.println("�rea del rombo: " + rombo.calcularArea());
		System.out.println("Per�metro del rombo: " + rombo.calcularPerimetro());
	}

}
