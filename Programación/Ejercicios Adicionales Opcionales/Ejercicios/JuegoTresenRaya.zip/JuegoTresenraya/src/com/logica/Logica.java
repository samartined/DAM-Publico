package com.logica;

import javax.swing.*;

import com.interfaz.Interfaz;

public class Logica {
	private Interfaz ui;
	private char jugadorActivo = 'X';
	private ImageIcon iconoX, iconoO;

	/**
	 * Contructor para formalizar la interfaz que consta de un tablero 3 x 3 con
	 * botones como elementos.
	 * 
	 * La posición de los botones en el tablero es la siguiente
	 * 
	 * | 1 | 2 | 3 | 
	 * | 4 | 5 | 6 | 
	 * | 7 | 8 | 9 |
	 * 
	 * Además, se inicializa las imagenes de cada ficha.
	 * 
	 * @param ui Interfaz
	 */
	public Logica(Interfaz ui) {
		this.ui = ui;
		iconoX = ui.establecerIcono("imagenes/x.jpg", 90, 90);
		iconoO = ui.establecerIcono("imagenes/o.jpg", 90, 90);
	}

	/**
	 * Este método establece la funcionalidad cuando se hace click en alguna de las
	 * partes del tablero
	 * 
	 * @param boton Botón sobre el que se ha hecho click
	 */
	public void click(JButton boton) {

		// FALTA POR TERMINAR
		// ¿Que hay que hacer al poner una ficha? 
		// validar si el movimiento es correcto, si es correcto, establecer la imagen, verificar si hay un ganador o empate 
		// y finalmente cambiar el turno de jugador


	}

	/**
	 * Método que comprueba si hay un ganador o se produce un empate
	 */
	private void comprobarGanador() {
		
		// FALTA POR TERMINAR
		// Hay que comprobar si hay un ganador o si hay un empate. Y preguntar si se quiere otra partida. 
		// En el caso que no se decida continuar el juego se cierra.
		
	}

	/**
	 * Función que revisa si una ficha esta 3 veces en horizontal, vertical o
	 * diagonal
	 * 
	 * @param icon Imagen de la ficha a validar
	 * @return Verdadero si la ficha esta 3 veces en horizontal, vertical o
	 *         diagonal. Falso en caso contrario
	 */
	private boolean validarFicha(ImageIcon icon) {
		
		// FALTA POR TERMINAR
		// Hay que comprobar si coincide tres veces la misma imagen en HORIZONTAL, VERTICAL O DIAGONAL
		
		return false;
	}

}
