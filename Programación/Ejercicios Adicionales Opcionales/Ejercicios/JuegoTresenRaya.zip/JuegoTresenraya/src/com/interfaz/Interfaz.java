package com.interfaz;



import javax.imageio.ImageIO;
import javax.swing.*;

import com.logica.Logica;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Interfaz extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7603351764833732406L;

	private JButton[][] botones = new JButton[3][3];
	private Logica logicaJuego;

	public Interfaz() {
		logicaJuego = new Logica(this);

		setTitle("Tres en Raya");
		setSize(300, 300);
		setResizable(false);
		setLayout(new GridLayout(3, 3));
		setLocationRelativeTo(null);

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				JButton buton = new JButton();
				botones[i][j] = buton;
				buton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						JButton source = (JButton) e.getSource();
						logicaJuego.click(source);
					}
				});
				add(buton);
			}
		}
	}

	public void actualizarImagen(JButton button, ImageIcon icon) {
		button.setIcon(icon);
	}

	public boolean comprobarTableroLleno() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (botones[i][j].getIcon() == null) {
					return false;
				}
			}
		}
		return true;
	}

	public void restablecerTablero() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				botones[i][j].setIcon(null);
			}
		}

	}

	public ImageIcon establecerIcono(String ruta, int ancho, int altura) {
		try {
			BufferedImage imagen = ImageIO.read(new File(ruta));
			Image dimg = imagen.getScaledInstance(ancho, altura, Image.SCALE_SMOOTH);
			return new ImageIcon(dimg);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Icon obtenerFichaTablero(int posicion) {
		
		switch(posicion) {
			case 1: return botones[0][0].getIcon();
			case 2: return botones[0][1].getIcon();
			case 3: return botones[0][2].getIcon();
			case 4: return botones[1][0].getIcon();
			case 5: return botones[1][1].getIcon();
			case 6: return botones[1][2].getIcon();
			case 7: return botones[2][0].getIcon();
			case 8: return botones[2][1].getIcon();
			case 9: return botones[2][2].getIcon();
		}
		
		return null;
		
	}
	
	public void mostrarMensaje(String mensaje) {
		JOptionPane.showMessageDialog(this, mensaje);
	}
	
	public void mostrarMensajeError(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);

	}

	public boolean mostrarMensajeOpciones(String mensaje) {
		return JOptionPane.showConfirmDialog(this, mensaje, "Tres en Raya",
				JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
	}
	
	public void cerrarJuego() {
		System.exit(0);
	}
}
