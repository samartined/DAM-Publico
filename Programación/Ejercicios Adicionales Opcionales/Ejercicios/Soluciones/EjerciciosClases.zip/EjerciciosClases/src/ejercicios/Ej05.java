package ejercicios;

public class Ej05 {

	public static void main(String[] args) {

		Coche cocheToyota = new Coche("Toyota", "Corolla", 2020, 50, 0.05);
		Viaje viaje = new Viaje(cocheToyota, 200);

		double coste = viaje.calcularCosteViaje(1.5);
		System.out.println(viaje);
		System.out.println("Coste del viaje: " + coste + " euros");

	}

}
