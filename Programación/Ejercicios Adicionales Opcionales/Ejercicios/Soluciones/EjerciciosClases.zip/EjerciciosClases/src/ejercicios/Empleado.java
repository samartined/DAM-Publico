package ejercicios;

import java.util.Date;

public class Empleado {
	private int identificador;
	private String nombre;
	private String apellido;
	private Date fechaNacimiento;
	private String email;
	private String categoria;
	private double salario;

	public Empleado(int identificador, String nombre, String apellido, Date fechaNacimiento, String email,
			String categoria, double salario) {
		this.identificador = identificador;
		this.nombre = nombre;
		this.apellido = apellido;
		this.fechaNacimiento = fechaNacimiento;
		this.email = email;
		this.categoria = categoria;
		this.salario = salario;
	}

	public void cambiarCategoria(String nuevaCategoria) {
		this.categoria = nuevaCategoria;
	}

	public int calcularEdad() {
		Date fechaActual = new Date();
		return fechaActual.getYear() - fechaNacimiento.getYear();
	}

	public void actualizarSalario(double incrementoPorcentual) {
		this.salario += salario * incrementoPorcentual / 100;
	}

}
