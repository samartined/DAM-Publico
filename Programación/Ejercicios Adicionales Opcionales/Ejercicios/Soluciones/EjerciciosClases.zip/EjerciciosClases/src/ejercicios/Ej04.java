package ejercicios;

public class Ej04 {
    public static void main(String[] args) {
        Tiempo tiempo = new Tiempo();

        System.out.println("Fecha actual: " + tiempo.mostrarFechaActual());

        tiempo.iniciarCronometro();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        tiempo.detenerCronometro();

        tiempo.detenerCronometro();
    }
}
