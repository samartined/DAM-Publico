package ejercicios;

public class Coche {
    private String marca;
    private String modelo;
    private int año;
    private double capacidadTanque;
    private double consumoPorKilometro;

    public Coche(String marca, String modelo, int año, double capacidadTanque, double consumoPorKilometro) {
        this.marca = marca;
        this.modelo = modelo;
        this.año = año;
        this.capacidadTanque = capacidadTanque;
        this.consumoPorKilometro = consumoPorKilometro;
    }

    public double getCapacidadTanque() {
        return capacidadTanque;
    }

    public double getConsumoPorKilometro() {
        return consumoPorKilometro;
    }
}

