package ejercicios;

public class Viaje {
    private Coche coche;
    private double distancia;

    public Viaje(Coche coche, double distancia) {
        this.coche = coche;
        this.distancia = distancia;
    }

    public double calcularCosteViaje(double precioCombustiblePorLitro) {
        return distancia * coche.getConsumoPorKilometro() * precioCombustiblePorLitro;
    }

    @Override
    public String toString() {
        return "Viaje con " + coche + "\nDistancia: " + distancia + " km";
    }
}

