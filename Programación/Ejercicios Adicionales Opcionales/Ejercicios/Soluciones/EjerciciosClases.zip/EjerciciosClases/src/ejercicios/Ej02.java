package ejercicios;

import java.util.Date;

public class Ej02 {
	
	public static void main(String[] args) {
		
		Empleado e1 = new Empleado(1, "Juan", "Pérez", new Date(), "juan.perez@email.com", "Gerente", 50000);
		e1.actualizarSalario(10);
		e1.cambiarCategoria("CEO");
		
		
	}
	


}
