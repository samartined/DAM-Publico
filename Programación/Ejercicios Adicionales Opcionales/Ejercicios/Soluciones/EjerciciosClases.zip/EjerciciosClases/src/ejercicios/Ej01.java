package ejercicios;

public class Ej01 {
	
	public static void main(String[] args) {
		
        Libro libro1 = new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, "Editorial Sudamericana", "978-3-16-148410-0");
        Libro libro2 = new Libro("1984", "George Orwell", 1949, "Secker and Warburg", "978-0-452-28423-4");
        Libro libro3 = new Libro("El señor de los anillos", "J.R.R. Tolkien", 1954, "Allen & Unwin", "978-0-395-19395-8");
        Libro libro4 = new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 1605, "Francisco de Robles", "978-84-206-1933-5");
        Libro libro5 = new Libro("La Odisea", "Homero", -800, "Editorial Antigua", "978-84-460-1943-3");

        System.out.println(libro1);
        System.out.println(libro2);
        System.out.println(libro3);
        System.out.println(libro4);
        System.out.println(libro5);

	}

}
