package ejercicios;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Tiempo {
    private long inicioCronometro;
    private boolean cronometroActivo;

    public Tiempo() {
        cronometroActivo = false;
    }

    public String mostrarFechaActual() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return formatoFecha.format(new Date());
    }

    public void iniciarCronometro() {
        if (!cronometroActivo) {
            inicioCronometro = System.currentTimeMillis();
            cronometroActivo = true;
            System.out.println("Cronómetro iniciado.");
        } else {
            System.out.println("El cronómetro ya est� en marcha.");
        }
    }

    public void detenerCronometro() {
        if (cronometroActivo) {
            long finCronometro = System.currentTimeMillis();
            long tiempoTranscurrido = finCronometro - inicioCronometro;
            cronometroActivo = false;
            System.out.println("Cronómetro detenido. Tiempo transcurrido: " + tiempoTranscurrido + " ms");
        } else {
            System.out.println("El cronómetro no está en marcha.");
        }
    }
}

