package ejercicios;

public class Ej03 {
	
	public static void main(String[] args) {
		
		Circulo circulo1 = new Circulo(10);
		Circulo circulo2 = new Circulo(27.8);
		
		System.out.println("El area del circulo 1 es: " + circulo1.calcularArea());
		System.out.println("El perimetro del circulo 1 es: " + circulo1.calcularPerimetro());
				
		System.out.println("El area del circulo 2 es: " + circulo2.calcularArea());
		System.out.println("El perimetro del circulo 2 es: " + circulo2.calcularPerimetro());
		
	}
	
}
