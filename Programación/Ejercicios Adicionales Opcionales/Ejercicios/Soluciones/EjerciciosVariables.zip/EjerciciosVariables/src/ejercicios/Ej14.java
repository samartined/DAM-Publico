package ejercicios;

public class Ej14 {
    public static void main(String[] args) {
        String numeroString = "123";
        int numero = Integer.parseInt(numeroString);
        System.out.println("El número es: " + numero);
    }
}

