package ejercicios;

public class Ej24 {
	
    enum Talla {
        PEQUEÑA, MEDIANA, GRANDE, EXTRA_GRANDE
    }

    public static void main(String[] args) {
        System.out.println("Tallas disponibles:");
        
        System.out.println(Talla.PEQUEÑA);
        System.out.println(Talla.MEDIANA);
        System.out.println(Talla.GRANDE);
        System.out.println(Talla.EXTRA_GRANDE);
        
    }
	
}
