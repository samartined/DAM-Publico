package ejercicios;

import java.util.Date;

public class Ej21 {
    public static void main(String[] args) {
        Date fecha = new Date();
        System.out.println("Fecha actual: " + fecha);
    }
}

