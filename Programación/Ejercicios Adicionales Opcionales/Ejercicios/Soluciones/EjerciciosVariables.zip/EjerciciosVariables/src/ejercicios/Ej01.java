package ejercicios;

public class Ej01 {
	
    public static void main(String[] args) {
    	
        int variable = 10;
        System.out.println("Valor de la variable entera: " + variable);
        
    }
    
}
