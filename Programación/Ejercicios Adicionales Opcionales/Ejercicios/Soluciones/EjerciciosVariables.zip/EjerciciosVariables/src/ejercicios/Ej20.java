package ejercicios;

import java.util.Scanner;

public class Ej20 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el capital inicial (P): ");
        double P = scanner.nextDouble();

        System.out.print("Ingrese la tasa de interés anual (r) en porcentaje: ");
        double r = scanner.nextDouble();
        r = r / 100;

        System.out.print("Ingrese el número de años (t): ");
        int t = scanner.nextInt();

        System.out.print("Ingrese el número de veces que el interés se compone por año (n): ");
        int n = scanner.nextInt();

        double A = P * Math.pow(1 + r / n, n * t);

        System.out.println("El valor futuro del capital es: " + A);
        
        scanner.close();
    }
}
