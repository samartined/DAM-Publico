package ejercicios;

public class Ej25 {
    public static void main(String[] args) {
        System.out.println("Direcciones cardinales:");
        System.out.println(Direccion.NORTE);
        System.out.println(Direccion.SUR);
        System.out.println(Direccion.ESTE);
        System.out.println(Direccion.OESTE);
    }
}
