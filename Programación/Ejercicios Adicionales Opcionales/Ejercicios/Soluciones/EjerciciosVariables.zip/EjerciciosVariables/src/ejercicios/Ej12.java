package ejercicios;

public class Ej12 {
    public static void main(String[] args) {
        char caracter = 'A';
        int variableInt = caracter;
        System.out.println("Valor int del char: " + variableInt);

        variableInt += 3;
        caracter = (char) variableInt;
        System.out.println("Nuevo valor de char: " + caracter);
    }
}

