package ejercicios;

public class Ej07 {
    public static void main(String[] args) {
    	int variableInt = 12345678;
        long variableLong = variableInt;
        
        System.out.println("variable int: " + variableInt);
        System.out.println("Variable long: " + variableLong);
        
    }
}
