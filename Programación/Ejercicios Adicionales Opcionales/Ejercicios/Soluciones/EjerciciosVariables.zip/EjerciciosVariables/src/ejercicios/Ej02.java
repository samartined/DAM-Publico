package ejercicios;

public class Ej02 {

	public static void main(String[] args) {
		int variable = 5;
		variable++;
		variable--;
		System.out.println("Resultado despu�s de incrementar y luego decrementar: " + variable);
	}

}
