package ejercicios;

public enum Direccion {
    NORTE, SUR, ESTE, OESTE
}

