package ejercicios;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Ej22 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese una fecha (dd/MM/yyyy):");
        String fechaTexto = scanner.nextLine();

        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            Date fecha = formato.parse(fechaTexto);
            System.out.println("Fecha convertida: " + fecha);
        } catch (Exception e) {
            System.out.println("Formato de fecha inv�lido.");
        }
        scanner.close();
    }
}

