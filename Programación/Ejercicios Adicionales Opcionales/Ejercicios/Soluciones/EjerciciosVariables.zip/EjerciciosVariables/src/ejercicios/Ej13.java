package ejercicios;

public class Ej13 {
    public static void main(String[] args) {
        String cadena = "Esta es una cadena de texto";
        int longitud = cadena.length();
        System.out.println("Longitud del string: " + longitud);
    }
}

