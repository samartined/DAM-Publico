package ejercicios;

public class Ej08 {
    public static void main(String[] args) {
    	
    	byte min = -128;
    	byte max = 127;
    	
        System.out.println("Valor mínimo de un byte: " + min);
        System.out.println("Valor máximo de un byte: " + max);
    }
}
