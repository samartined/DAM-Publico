package ejercicios;

public class Ej04 {
	public static void main(String[] args) {
		final double PI = 3.14159;
		double radio = 5;
		double area = PI * radio * radio;
		System.out.println("Área del círculo con radio 5: " + area);
	}
}
