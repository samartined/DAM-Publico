package ejercicios;

import java.util.Scanner;

public class Ej18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el valor de x: ");
        double x = scanner.nextDouble();

        double resultado = Math.pow(Math.E, Math.PI * x);

        System.out.println("El resultado es: " + resultado);
        
        scanner.close();
    }
}

