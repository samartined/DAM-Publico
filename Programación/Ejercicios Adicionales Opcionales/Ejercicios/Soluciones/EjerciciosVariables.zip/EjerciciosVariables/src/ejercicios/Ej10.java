package ejercicios;

public class Ej10 {
    public static void main(String[] args) {
    	
        int numero1 = 20;
        int numero2 = 15;

        boolean resultado = numero1 > numero2;

        System.out.println("El resultado de la comparación es: " + resultado);
    }
}

