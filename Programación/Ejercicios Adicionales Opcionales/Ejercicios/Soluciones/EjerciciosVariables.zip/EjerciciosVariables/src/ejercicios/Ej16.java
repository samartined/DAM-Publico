package ejercicios;

public class Ej16 {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;

        boolean andResultado = a && b; 
        boolean orResultado = a || b;
        boolean notResultado = !a; 

        System.out.println("AND: " + andResultado);
        System.out.println("OR: " + orResultado);
        System.out.println("NOT: " + notResultado);
    }
}

