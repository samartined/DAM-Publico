package ejercicios;

public class Ej11 {
    public static void main(String[] args) {
        String str1 = "Hola ";
        String str2 = "Mundo!";

        String concatenado = str1 + str2;

        System.out.println("Resultado de la concatenación: " + concatenado);
    }
}
