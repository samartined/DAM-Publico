package ejercicios;

public class Ej17 {
    public static void main(String[] args) {
        double valor = 9.5;
        double raiz = Math.sqrt(valor);
        long redondeado = Math.round(raiz);

        System.out.println("Raíz cuadrada: " + raiz);
        System.out.println("Redondeado al entero más cercano: " + redondeado);
    }
}
