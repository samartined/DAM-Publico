package ejercicios;

public class Ej15 {
    public static void main(String[] args) {
        final int VELOCIDAD_LUZ = 299792458; 
        double distancia = 149.6e9; 

        double tiempo = distancia / VELOCIDAD_LUZ; 
        tiempo /= 60; 

        System.out.println("Tiempo que tarda la luz en viajar desde el Sol a la Tierra: " + tiempo + " minutos");
    }
}
