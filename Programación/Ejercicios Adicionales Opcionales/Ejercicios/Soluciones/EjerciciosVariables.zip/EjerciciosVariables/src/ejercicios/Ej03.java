package ejercicios;

public class Ej03{
    public static void main(String[] args) {
        final int DIAS_EN_SEMANA = 7;
        int resultado = DIAS_EN_SEMANA * 5;
        System.out.println("Días en cinco semanas: " + resultado);
    }
}
