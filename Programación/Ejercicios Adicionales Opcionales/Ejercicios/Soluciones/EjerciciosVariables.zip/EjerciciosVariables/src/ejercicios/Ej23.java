package ejercicios;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Ej23 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

        try {
            System.out.println("Ingrese la fecha de inicio (dd/MM/yyyy):");
            Date fechaInicio = formato.parse(scanner.nextLine());

            System.out.println("Ingrese la fecha de fin (dd/MM/yyyy):");
            Date fechaFin = formato.parse(scanner.nextLine());

            long diferencia = fechaFin.getTime() - fechaInicio.getTime();
            // Convertir milisegundos a días
            long dias = diferencia / (24 * 60 * 60 * 1000); 
            System.out.println("Diferencia en días: " + dias);
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido.");
        } 
            
        scanner.close();
        
    }
}
