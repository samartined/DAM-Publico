package ejercicios;

import java.util.Scanner;

public class Ej19 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el lado a del triángulo: ");
        double a = scanner.nextDouble();

        System.out.print("Ingrese el lado b del triángulo: ");
        double b = scanner.nextDouble();

        System.out.print("Ingrese el lado c del triángulo: ");
        double c = scanner.nextDouble();

        double s = (a + b + c) / 2;
        double area = Math.sqrt(s * (s - a) * (s - b) * (s - c));

        System.out.println("El área del triángulo es: " + area);
        
        scanner.close();
    }
}

