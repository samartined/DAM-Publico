package ejercicios;

public class Ej05 {
    public static void main(String[] args) {
        float variableFloat = 0.1234567f;
        double variableDouble = 0.123456789012345;
        System.out.println("Variable float: " + variableFloat);
        System.out.println("Variable double: " + variableDouble); 
    }
}
