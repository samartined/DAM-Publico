import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import com.interfaz.Interfaz;


public class Principal {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			Interfaz game = new Interfaz();
			game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			game.setVisible(true);
		});

	}

}
