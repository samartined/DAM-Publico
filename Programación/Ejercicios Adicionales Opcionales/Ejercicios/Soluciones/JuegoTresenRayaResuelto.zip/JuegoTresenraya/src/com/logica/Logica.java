package com.logica;

import javax.swing.*;

import com.interfaz.Interfaz;

public class Logica {
	private Interfaz ui;
	private char jugadorActivo = 'X';
	private ImageIcon iconoX, iconoO;

	/**
	 * Contructor para formalizar la interfaz que consta de un tablero 3 x 3 con
	 * botones como elementos.
	 * 
	 * La posición de los botones en el tablero es la siguiente
	 * 
	 * | 1 | 2 | 3 | 
	 * | 4 | 5 | 6 | 
	 * | 7 | 8 | 9 |
	 * 
	 * Además, se inicializa las imagenes de cada ficha.
	 * 
	 * @param ui Interfaz
	 */
	public Logica(Interfaz ui) {
		this.ui = ui;
		iconoX = ui.establecerIcono("imagenes/x.jpg", 90, 90);
		iconoO = ui.establecerIcono("imagenes/o.jpg", 90, 90);
	}

	/**
	 * Este método establece la funcionalidad cuando se hace click en alguna de las
	 * partes del tablero
	 * 
	 * @param boton Botón sobre el que se ha hecho click
	 */
	public void click(JButton boton) {
		// Aquí los estudiantes implementarán la lógica para manejar los clics en los
		// botones
		// Por ejemplo, verificar si el botón ya está ocupado, cambiar el jugador, etc.

		if (boton.getIcon() == null && jugadorActivo != ' ') {

			boton.setIcon(jugadorActivo == 'X' ? iconoX : iconoO);
			comprobarGanador();
			jugadorActivo = (jugadorActivo == 'X') ? 'O' : 'X';

		} else {
			ui.mostrarMensajeError("Esta casilla ya está ocupada.");
		}

	}

	/**
	 * Método que comprueba si hay un ganador o se produce un empate
	 */
	private void comprobarGanador() {
		if (validarFicha(iconoX) || validarFicha(iconoO)) {
			if (ui.mostrarMensajeOpciones("Jugador " + jugadorActivo + " gana. ¿Quieres jugar otra vez?")) {
				ui.restablecerTablero();
				jugadorActivo = 'X';
			} else {
				ui.cerrarJuego();
			}
		} else if (ui.comprobarTableroLleno()) {
			if (ui.mostrarMensajeOpciones("Es un empate. ¿Quieres jugar otra vez?")) {
				ui.restablecerTablero();
				jugadorActivo = 'X';
			} else {
				ui.cerrarJuego();
			}
		}
	}

	/**
	 * Función que revisa si una ficha esta 3 veces en horizontal, vertical o
	 * diagonal
	 * 
	 * @param icon Imagen de la ficha a validar
	 * @return Verdadero si la ficha esta 3 veces en horizontal, vertical o
	 *         diagonal. Falso en caso contrario
	 */
	private boolean validarFicha(ImageIcon icon) {
		for (int i = 0; i < 3; i++) {
			// Validación vertical
			if (ui.obtenerFichaTablero(i * 3 + 1) == icon && ui.obtenerFichaTablero(i * 3 + 2) == icon && ui.obtenerFichaTablero(i * 3 + 3) == icon) {
				return true;
			}

			// Validación horizontal
			if (ui.obtenerFichaTablero(1 + i) == icon && ui.obtenerFichaTablero(4 + i) == icon && ui.obtenerFichaTablero(7 + i) == icon) {
				return true;
			}
		}

		// Validación diagonal (Izquierda a Derecha)
		if (ui.obtenerFichaTablero(1) == icon && ui.obtenerFichaTablero(5) == icon && ui.obtenerFichaTablero(9) == icon) {
			return true;
		}

		// Validación diagonal (Derecha a Izquierda)
		if (ui.obtenerFichaTablero(3) == icon && ui.obtenerFichaTablero(5) == icon && ui.obtenerFichaTablero(7) == icon) {
			return true;
		}

		return false;
	}

}
