package ejercicios;

import java.util.Scanner;

public class Ej06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un tipo de vehículo (coche, moto, bicicleta): ");
        String tipo = scanner.nextLine();

        switch (tipo.toLowerCase()) {
            case "coche":
                System.out.println("Has seleccionado coche.");
                break;
            case "moto":
                System.out.println("Has seleccionado moto.");
                break;
            case "bicicleta":
                System.out.println("Has seleccionado bicicleta.");
                break;
            default:
                System.out.println("Tipo de vehículo no válido.");
        }
        
        scanner.close();
    }
}
