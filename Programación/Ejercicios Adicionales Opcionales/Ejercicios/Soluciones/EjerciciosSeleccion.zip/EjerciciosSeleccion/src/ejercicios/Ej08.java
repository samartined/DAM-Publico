package ejercicios;

import java.util.Scanner;

public class Ej08 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la cantidad en euros: ");
        double euros = scanner.nextDouble();

        System.out.println("1. Convertir a dólares");
        System.out.println("2. Convertir a libras esterlinas");
        System.out.println("3. Convertir a yenes");
        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1: 
                System.out.println(euros + " euros son " + (euros * 1.12) + " dólares");
                break;
            case 2: 
                System.out.println(euros + " euros son " + (euros * 0.85) + " libras");
                break;
            case 3: 
                System.out.println(euros + " euros son " + (euros * 129.53) + " yenes");
                break;
            default:
                System.out.println("Opción no válida");
        }
        scanner.close();
    }
}
