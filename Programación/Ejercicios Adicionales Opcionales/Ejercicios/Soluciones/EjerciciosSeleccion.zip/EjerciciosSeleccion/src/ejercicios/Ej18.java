package ejercicios;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Ej18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

        try {
            System.out.println("Inserta la primera fecha (dd/MM/yyyy):");
            Date primeraFecha = formato.parse(scanner.nextLine());

            System.out.println("Inserta la segunda fecha (dd/MM/yyyy):");
            Date segundaFecha = formato.parse(scanner.nextLine());

            if (primeraFecha.after(segundaFecha)) {
                System.out.println("La primera fecha es más reciente.");
            } else if (segundaFecha.after(primeraFecha)) {
                System.out.println("La segunda fecha es más reciente.");
            } else {
                System.out.println("Las fechas son iguales.");
            }
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido.");
        }
        
        scanner.close();
    }
}


