package ejercicios;

import java.util.Scanner;

public class Ej12 {
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);

        double a, b;
        
        System.out.print("Ingrese la variable a: ");
        a = scanner.nextDouble();
        System.out.print("Ingrese la variable b: ");
        b = scanner.nextDouble();

        if (a != 0) {
            double solucion = -b / a;
            System.out.println("La solución es x = " + solucion);
        } else {
            System.out.println("La ecuación no tiene soluci�n.");
        }

        scanner.close();
    }
}

