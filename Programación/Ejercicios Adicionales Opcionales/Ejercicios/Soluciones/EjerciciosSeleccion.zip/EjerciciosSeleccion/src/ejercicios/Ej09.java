package ejercicios;

import java.util.Scanner;

public class Ej09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el peso del paquete en kilos: ");
        double peso = scanner.nextDouble();
        double tarifa;

        if (peso < 10) {
            tarifa = 10 + peso * 0.001;
        } else if (peso <= 50) {
            tarifa = 25 + peso * 0.001;
        } else {
            tarifa = 30 + peso * 0.002;
        }

        System.out.println("La tarifa de envío es: " + tarifa + " euros");
        scanner.close();
    }
}

