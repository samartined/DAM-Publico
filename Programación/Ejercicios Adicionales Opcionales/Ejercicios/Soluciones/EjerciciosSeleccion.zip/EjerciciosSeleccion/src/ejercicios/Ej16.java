package ejercicios;

import java.util.Scanner;
import java.util.Random;

public class Ej16 {
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);

        System.out.print("Elige (piedra, papel, tijera): ");
        String usuario = scanner.nextLine().toLowerCase();
        
        String computadora = "";

        switch (new Random().nextInt(3)+1) {
			case 1: computadora = "piedra";
					break;
			case 2: computadora = "papel";
					break;
			case 3: computadora = "tijera";
					break;
		}
        
        System.out.println("Elegiste: " + usuario);
        System.out.println("La computadora eligi�: " + computadora);

        if (usuario.equals(computadora)) {
            System.out.println("Empate.");
        } else if ((usuario.equals("piedra") && computadora.equals("tijera")) ||
                   (usuario.equals("papel") && computadora.equals("piedra")) ||
                   (usuario.equals("tijera") && computadora.equals("papel"))) {
            System.out.println("Ganaste.");
        } else {
            System.out.println("Perdiste.");
        }

        scanner.close();
    }
}

