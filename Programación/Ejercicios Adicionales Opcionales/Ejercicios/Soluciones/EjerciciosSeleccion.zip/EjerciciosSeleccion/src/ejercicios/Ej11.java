package ejercicios;

import java.util.Scanner;

public class Ej11 {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		double numerador, denominador;

		System.out.print("Inserta el numerador: ");
		if (!scanner.hasNextDouble()) {
			System.out.println("numerador no válido");
		} else {
			numerador = scanner.nextDouble();
			System.out.print("Inserta el denominador: ");
			if (!scanner.hasNextDouble()) {
				System.out.println("denominador no válido");
			} else {
				denominador = scanner.nextDouble();

				if (denominador == 0) {
					System.out.println("Error: No se puede dividir por cero.");
				} else {
					double resultado = numerador / denominador;
					System.out.println("Resultado: " + resultado);
				}

			}

		}

		scanner.close();
	}
}
