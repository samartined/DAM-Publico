package ejercicios;

import java.util.Scanner;

public class Ej15 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserta su presupuesto: ");
        float presupuesto = scanner.nextFloat();

        System.out.println("Inserta su preferencia (mar, montaña, ciudad): ");
        String preferencia = scanner.nextLine().toLowerCase();
        
        if(preferencia.equals("mar") || preferencia.equals("montaña") || preferencia.equals("ciudad") ) {
        	 if (presupuesto >= 200 && presupuesto <= 700) {
                 if (preferencia.equals("mar")) {
                     System.out.println("Destino sugerido: Mar menor (Murcia)");
                 } else if (preferencia.equals("montaña")) {
                     System.out.println("Destino sugerido: Sierra Nevada (Granada)");
                 } else if (preferencia.equals("ciudad")) {
                     System.out.println("Destino sugerido: Lisboa");
                 } 
             } else if (presupuesto >= 701 && presupuesto <= 1500) {
                 if (preferencia.equals("mar")) {
                     System.out.println("Destino sugerido: Magaluf (Mallorca)");
                 } else if (preferencia.equals("montaña")) {
                     System.out.println("Destino sugerido: Los Alpes (Suiza)");
                 } else if (preferencia.equals("ciudad")) {
                     System.out.println("Destino sugerido: Barcelona");
                 }
             } else if (presupuesto > 1500) {
                 if (preferencia.equals("mar")) {
                     System.out.println("Destino sugerido: Playa Paraíso (Cuba)");
                 } else if (preferencia.equals("montaña")) {
                     System.out.println("Destino sugerido: Montañas Rocosas (Aspen)");
                 } else if (preferencia.equals("ciudad")) {
                     System.out.println("Destino sugerido: Tokio");
                 } 
             } else {
                 System.out.println("No hay ninguna sugerencia para ese presupuesto");
             }

        } else {
            System.out.println("Preferencia no válida");
        }

       
        scanner.close();
    }
}
