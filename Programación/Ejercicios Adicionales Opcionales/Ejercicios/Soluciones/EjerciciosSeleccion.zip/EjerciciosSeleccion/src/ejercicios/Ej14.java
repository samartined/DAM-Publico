package ejercicios;

import java.util.Scanner;

public class Ej14 {
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        
        boolean valido = true;

        System.out.print("Escribe la contraseña: ");
        String contraseña = scanner.nextLine();

        if (contraseña.length() < 8) {
           System.out.println("La contraseña es demasiado corta. Debe tener al menos 8 caracteres.");
           valido = false;
        }
        
        if (!contraseña.matches(".*\\d.*")) {
            System.out.println("La contraseña debe incluir al menos un número.");
            valido = false;
        }

        if (!contraseña.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
            System.out.println("La contraseña debe incluir al menos un símbolo.");
            valido = false;
        }
        
        if (!contraseña.matches(".*[A-Z].*")) {
            System.out.println("La contraseña debe incluir al menos una letra mayúscula.");
            valido = false;
        }
        
        if(valido)
        	System.out.println("Contraseña válida");
        
        
        scanner.close();
    }
}
