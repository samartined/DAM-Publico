package ejercicios;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Ej19 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

		System.out.println("Inserta la fecha de nacimiento (dd/MM/yyyy):");
		String fechaNacimiento = scanner.nextLine();

		Date fechaActual = new Date();

		// Obtener el dia, mes y año de la fecha actual
		int diaActual = Integer.parseInt(formatoFecha.format(fechaActual).substring(0, 2));
		int mesActual = Integer.parseInt(formatoFecha.format(fechaActual).substring(3, 5));
		int añoActual = Integer.parseInt(formatoFecha.format(fechaActual).substring(6, 10));

		// Obtener el dia, mes y año de la fecha indicada
		int diaNacimiento = Integer.parseInt(fechaNacimiento.substring(0, 2));
		int mesNacimiento = Integer.parseInt(fechaNacimiento.substring(3, 5));
		int añoNacimiento = Integer.parseInt(fechaNacimiento.substring(6, 10));

		// Calcular la diferencia de años
		int edad = añoActual - añoNacimiento;

		// Ajustar la edad si aún no ha llegado el mes o día de nacimiento
		if (mesActual < mesNacimiento || (mesActual == mesNacimiento && diaActual < diaNacimiento)) {
			edad--;
		}

		System.out.println("Su edad es: " + edad + " años.");

		scanner.close();

	}
}
