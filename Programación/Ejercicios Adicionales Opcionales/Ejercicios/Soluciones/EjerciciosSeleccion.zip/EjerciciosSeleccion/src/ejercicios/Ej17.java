package ejercicios;

import java.util.Scanner;

public class Ej17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Indica la latitud (entre -90 y 90): ");
        double latitud = scanner.nextDouble();

        System.out.print("Indica la longitud (entre -180 y 180): ");
        double longitud = scanner.nextDouble();

        if (latitud > 0) {
            System.out.print("Según la latitud te encuentras en el Hemisferio Norte");
        } else if (latitud < 0) {
            System.out.print("Según la latitud te encuentras en el Hemisferio Sur");
        } else {
            System.out.print("Según la latitud te encuentras en el Ecuador");
        }

        if (longitud > 0) {
            System.out.println(" y según la longitud te encuentra en el Hemisferio Este.");
        } else if (longitud < 0) {
            System.out.println(" y según la longitud te encuentra en el Hemisferio Oeste.");
        } else {
            System.out.println(" y según la longitud te encuentra en el Meridiano de Greenwich.");
        }

        scanner.close();
    }
}
