package ejercicios;

import java.util.Scanner;

public class Ej02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número entre 1 y 100: ");
        int numero = scanner.nextInt();

        if (numero < 1 || numero > 100) {
            System.out.println("Número fuera de rango.");
        } else if (numero < 10) {
            System.out.println("Número bajo.");
        } else if (numero <= 100) {
            System.out.println("Número medio.");
        } else {
            System.out.println("Número alto.");
        }
        
        scanner.close();
    }
}
