package ejercicios;

import java.util.Scanner;

public class Ej07 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Ingrese su edad: ");
		int edad = scanner.nextInt();		

		switch (edad) {
			case 0, 1, 2, 3, 4, 5 -> System.out.println("Infancia");
			case 6, 7, 8, 9, 10, 11 -> System.out.println("Niñez");
			case 12, 13, 14, 15, 16, 17 -> System.out.println("Adolescencia");
			case 18, 19, 20, 21, 22, 23, 24, 25 -> System.out.println("Juventud");
			default -> {
				if (edad > 25) {
					System.out.println("Adulto");
				} else {
					System.out.println("Edad no válida");
				}
			}
		}
		scanner.close();
	}
}
