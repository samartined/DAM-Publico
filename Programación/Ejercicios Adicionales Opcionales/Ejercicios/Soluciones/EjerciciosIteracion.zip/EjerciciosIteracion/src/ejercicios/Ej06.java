package ejercicios;

import java.util.Scanner;

public class Ej06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese números (0 para terminar):");

        int suma = 0, contador = 0, numero;
        while ((numero = scanner.nextInt()) != 0) {
            suma += numero;
            contador++;
        }

        double promedio = contador > 0 ? (double) suma / contador : 0;
        System.out.println("El promedio de los números ingresados es: " + promedio);
        
        scanner.close();
    }
}
