package ejercicios;

import java.util.Scanner;

public class Ej09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numero;

        do {
            System.out.println("Ingrese un número entero mayor a 10:");
            numero = scanner.nextInt();
        } while (numero < 10);

        int ultimoDigito = numero % 10;
        int primerDigito = numero;

        while (primerDigito >= 10) {
            primerDigito /= 10;
        }

        int suma = primerDigito + ultimoDigito;
        System.out.println("La suma del primer y último dígito es: " + suma);
        scanner.close();
    }
}

