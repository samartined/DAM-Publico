package ejercicios;

import java.util.Scanner;

public class Ej03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese un número para ver su tabla de multiplicar:");
        int numero = scanner.nextInt();

        for (int i = 1; i <= 10; i++) {
            System.out.println(numero + " * " + i + " = " + (numero * i));
        }
        
        scanner.close();
    }
}

