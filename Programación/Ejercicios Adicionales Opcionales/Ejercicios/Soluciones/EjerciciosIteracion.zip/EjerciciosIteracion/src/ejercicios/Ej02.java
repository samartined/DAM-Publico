package ejercicios;

public class Ej02 {
    public static void main(String[] args) {
        int contador = 10;
        while (contador >= 1) {
            System.out.println(contador);
            contador--;
        }
    }
}
