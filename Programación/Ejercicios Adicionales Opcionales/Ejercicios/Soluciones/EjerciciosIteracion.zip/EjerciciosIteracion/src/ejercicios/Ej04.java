package ejercicios;

import java.util.Scanner;

public class Ej04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese un número N:");
        int N = scanner.nextInt();

        int suma = 0;
        int i = 1;
        do {
            suma += i;
            i++;
        } while (i <= N);

        System.out.println("La suma de los números desde 1 hasta " + N + " es: " + suma);
        
        scanner.close();
    }
}

