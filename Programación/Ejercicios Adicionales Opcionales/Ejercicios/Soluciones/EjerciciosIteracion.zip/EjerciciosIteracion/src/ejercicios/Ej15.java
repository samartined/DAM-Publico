package ejercicios;

public class Ej15 {
    enum DiasSemana {
        LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
    }

    public static void main(String[] args) {
        // Usando bucle for
        for (int i= 0 ; i < DiasSemana.values().length; i++) {
            System.out.println(DiasSemana.values()[i]);
        }

        // Usando foreach
        for (DiasSemana dia : DiasSemana.values()) {
            System.out.println(dia);
        }
    }
}

