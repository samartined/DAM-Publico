package ejercicios;

public class Ej18 {
    public static void main(String[] args) {
        int horas = 0, minutos = 0, segundos = 0;

        System.out.println("Cronómetro");

        while (true) {
    
            System.out.printf("%02d:%02d:%02d\n", horas, minutos, segundos);

            segundos++;

            if (segundos == 60) {
                segundos = 0;
                minutos++;

                if (minutos == 60) {
                    minutos = 0;
                    horas++; 
                }
            }
            
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

