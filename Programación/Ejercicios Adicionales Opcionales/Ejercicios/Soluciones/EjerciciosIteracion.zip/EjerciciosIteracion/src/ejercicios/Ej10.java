package ejercicios;

import java.util.Scanner;

public class Ej10 {
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese un texto:");
        String texto = scanner.nextLine();
        System.out.println("Ingrese el carácter a buscar:");
        char caracter = scanner.nextLine().charAt(0);

        int contador = 0;
        int i = 0;
        while (i < texto.length()) {
            if (texto.charAt(i) == caracter) {
                contador++;
            }
            i++;
        }

        System.out.println("El carácter '" + caracter + "' aparece " + contador + " veces.");
        scanner.close();
    }
}
