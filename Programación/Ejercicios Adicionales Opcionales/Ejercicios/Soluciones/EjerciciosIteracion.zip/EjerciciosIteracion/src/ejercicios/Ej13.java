package ejercicios;

import java.util.Random;

import java.util.Scanner;


public class Ej13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Inserta el número máximo de intentos para lanzar la moneda:");
        int maxIntentos = scanner.nextInt();
        boolean cara = false;
        int intentos = 0;

        while (intentos < maxIntentos && !cara) {
            cara = new Random().nextBoolean(); 
            System.out.println("Intento " + (intentos + 1) + ": " + (cara ? "Cara" : "Cruz"));
            intentos++;
        }

        if (!cara) {
            System.out.println("No se ha conseguido cara después de " + maxIntentos + " intentos.");
        } else {
            System.out.println("Cara conseguida en el intento " + intentos);
        }
        
        scanner.close();
    }
}
