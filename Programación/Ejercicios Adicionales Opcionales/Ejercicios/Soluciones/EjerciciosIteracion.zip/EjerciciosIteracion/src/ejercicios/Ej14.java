package ejercicios;

import java.util.Scanner;
import java.util.Random;

public class Ej14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int numeroSecreto = random.nextInt(100) + 1;
        int intentos = 0;

        System.out.println("Adivina el número entre 1 y 100");

        while (true) {
            System.out.print("Inserta un número a adivinar: ");
            int eleccion = scanner.nextInt();
            intentos++;

            if (eleccion == numeroSecreto) {
                System.out.println("Has adivinado el número en " + intentos + " intentos.");
                break;
            } else if (eleccion < numeroSecreto) {
                System.out.println("El número es mayor que " + eleccion);
            } else {
                System.out.println("El número es menor que " + eleccion);
            }
        }
        
        scanner.close();
    }
}
