package ejercicios;

import java.util.Scanner;

public class Ej17 {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Indica el importe total a retirar:");
		double cantidad = scanner.nextDouble();

		// Convertir la cantidad a la unidad mínima. 1 € = 100 centimos
		int centimos = (int) Math.round(cantidad * 100);

		int euros2 = centimos / 200;
		centimos %= 200;
		int euros1 = centimos / 100;
		centimos %= 100;
		int monedas50 = centimos / 50;
		centimos %= 50;
		int monedas20 = centimos / 20;
		centimos %= 20;
		int monedas10 = centimos / 10;
		centimos %= 10;
		int monedas5 = centimos / 5;
		centimos %= 5;
		int monedas2 = centimos / 2;
		centimos %= 2;
		int monedas1 = centimos;

		// Imprimir el resultado
		System.out.println("Cambio para " + cantidad + " euros:");
		if (euros2 > 0)
			System.out.println("2€: " + euros2);
		if (euros1 > 0)
			System.out.println("1€: " + euros1);
		if (monedas50 > 0)
			System.out.println("0.50€: " + monedas50);
		if (monedas20 > 0)
			System.out.println("0.20€: " + monedas20);
		if (monedas10 > 0)
			System.out.println("0.10€: " + monedas10);
		if (monedas5 > 0)
			System.out.println("0.05€: " + monedas5);
		if (monedas2 > 0)
			System.out.println("0.02€: " + monedas2);
		if (monedas1 > 0)
			System.out.println("0.01€: " + monedas1);
		
		scanner.close();

	}
}