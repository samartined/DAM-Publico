package ejercicios;

import java.util.Scanner;

public class Ej12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el número N para la secuencia de Fibonacci:");
        int n = scanner.nextInt();

        int a = 0, b = 1, c;
        System.out.println("Secuencia de Fibonacci hasta " + n + ":");
        while (a <= n) {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
        }
        scanner.close();
    }
}
