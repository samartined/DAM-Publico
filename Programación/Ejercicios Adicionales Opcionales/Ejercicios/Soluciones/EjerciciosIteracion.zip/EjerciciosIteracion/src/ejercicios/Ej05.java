package ejercicios;

import java.util.Scanner;

public class Ej05 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int numero, minimo = 999999999;
		int numIntento = 0;

		do {
			System.out.println("Ingrese números (0 para terminar):");
			numero = scanner.nextInt();
			if(numero != 0 && numero < minimo) {
				minimo = numero;
			}
			numIntento++;
		} while (numero != 0);

		if(numIntento > 1) {
			System.out.println("El número más pequeño es: " + minimo);
		} else {
			System.out.println("No ha introducido ningun número");
		}
		
		scanner.close();
	}
}
