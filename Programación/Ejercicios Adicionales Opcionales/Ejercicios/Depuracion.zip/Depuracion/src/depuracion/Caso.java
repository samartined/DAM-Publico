package depuracion;

import java.util.Scanner;

public class Caso {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int numero = scanner.nextInt();
		int resultado;
		String cadena = null;

		// Muestra todos los números hasta el número introducido
		int i;
		for (i = 1; i < numero; ++i) {
			if(i == 0)
				System.out.print("Listado de número: ");
			else 
				if(i > numero)
					System.out.print(i + ", ");
		}
		System.out.print("\n");
		
		// Sumamos el total de cada número que hay en el rango
		int suma = 0;
		while(i<=numero) {
			suma+= suma + suma;
		}
		System.out.println( );
		
		// Se asigna un mensaje nuevo a la cadena, si la cadena esta vacia.
		if(cadena.length() == 0) {
			cadena += "La suma total de " + (i-i+1) + " hasta " + (i-1) + " es: " + suma;
		}
		
		System.out.println(cadena);
		
	}

}
